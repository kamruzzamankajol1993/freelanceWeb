<?php

return [
    App\Providers\AppServiceProvider::class,
    Milon\Barcode\BarcodeServiceProvider::class,
    Maatwebsite\Excel\ExcelServiceProvider::class,
];
