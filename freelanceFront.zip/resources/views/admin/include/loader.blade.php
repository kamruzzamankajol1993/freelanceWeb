<div class="preloader">
    <div class="loader"></div>
  </div>