<!DOCTYPE html>
<html>
<head>
    <title>Your OTP Code</title>
</head>
<body>
    <h1>Your OTP is: {{ $otp }}</h1>
    <p>Please use this code to verify your account.</p>
</body>
</html>
